#include "clear.h"

void Clear()//清屏 C
{
    system("clear"); //"clear"为Linux终端清屏命令（实质是向上翻页）
}