#ifndef _CLEAR_H_
#define _CLEAR_H_
#include <stdlib.h>
/****函数声明***/
void Clear();   //清屏

#endif