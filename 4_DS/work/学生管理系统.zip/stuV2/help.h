#ifndef _SCORE_H_
#define __SCORE_H_
#include <stdio.h>
/****函数声明***/
void Help();//帮助菜单显示函数

#endif