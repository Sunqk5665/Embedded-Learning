#include "merge.h"

seqlist_t *CreatEpList()
{
	seqlist_t *p = (seqlist_t *)malloc(sizeof(seqlist_t));
	if(NULL == p){
		printf("CreatEpList failed!\n");
	}
	p->last = -1;
	return p;
}

int InsertSeqlist(seqlist_t *p,int post,int data)
{
	int i=0;
	if(post<0 || post>p->last+1 || IsFullSeqlist(p))
	{
		printf("InsertInto failed!\n");
		return 0;
	}
	for(i=p->last;i>=post;i--)
	{
		p->data[i+1] = p->data[i];
	}
	p->data[post] = data;
	p->last++;
	return 0;
}
void ShowList(seqlist_t *p)
{
	int i;
	for(i=0;i<=p->last;i++)
	{
		printf("p[%d] = %d\n",i,p->data[i]);
	}
	putchar(10);
}


int IsFullSeqlist(seqlist_t *p)
{
	return p->last == N-1;

}

void OrderMerge(seqlist_t *pa,seqlist_t *pb)
{
	int i=0,j=0;
	while(1)
	{
		if(pa->data[i] > pb->data[j])
		{
			InsertSeqlist(pa,i,pb->data[j]);
			i++;
			j++;
		}
		if(pa->data[i] <= pb->data[j])
		{
			InsertSeqlist(pa,i+1,pb->data[j]);
			i+=2;
			j++;
		}
		if(j>pb->last)
			break;

	}
}

