#include "merge.h"

int main(int argc, const char *argv[])
{
	seqlist_t *pa = CreatEpList();
	seqlist_t *pb = CreatEpList();

	InsertSeqlist(pa,0,2);
	InsertSeqlist(pa,1,4);
	InsertSeqlist(pa,2,6);
	InsertSeqlist(pa,3,8);
	ShowList(pa);
	
	InsertSeqlist(pb,0,1);
	InsertSeqlist(pb,1,3);
	InsertSeqlist(pb,2,5);
	InsertSeqlist(pb,3,7);
	ShowList(pb);

	OrderMerge(pa,pb);
	ShowList(pa);

	free(pa);
	pa = NULL;
	free(pb);
	pb = NULL;
	return 0;
}
